﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiscuitBattle.Store.Decks
{
    public enum BiscuitAttribute { Texture, DunkIntegrity, Snap, Moistness, Sweetness }
}
