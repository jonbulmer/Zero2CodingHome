using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BiscuitBattle.Tests
{
    [TestClass]
    public class GameLogicTests
    {
        [TestMethod]
        public void game_picks_winning_player_correctly()
        {
           
        }
    }

}
